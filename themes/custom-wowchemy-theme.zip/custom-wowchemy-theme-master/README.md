## Custom Settings

These are my settings for the [Wowchemy](https://wowchemy.com/) theme for [Hugo](https://gohugo.io/).

It produces a website like mine: https://matteocourthoud.github.io/.

I have the full guide here: https://matteocourthoud.github.io/post/website/.

Feel free to use :)

![mywebsite](mywebsite.png)